﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DataService.Models;
using DataService.Data;
using DataService.Models.DatabaseModels;
using System.Data;
using MySql.Data.MySqlClient;

namespace DataService.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public  IActionResult Index()
        {

            return View();
        }
        [Route("Home/GetHangJobData/{trackerType}")]
        [HttpGet]
        public async Task<JsonResult> GetHangJobData(string trackerType)
        {
            List<HangJob> hj = new List<HangJob>();
            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DB.connection_string))
            {
                using (MySqlCommand cmd = new MySqlCommand("GetHangJobs", con))
                {
                    //string trackerType = "EFS";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@typeTracker", trackerType);
                    using (MySqlDataAdapter sda = new MySqlDataAdapter())
                    {
                        sda.SelectCommand = cmd;
                        sda.Fill(dt);

                    }
                }
            }

            return Json(new
            {
                data = dt

            });
        }
        [HttpGet]
        public async Task<JsonResult> GetTrackerTakedown()
        {
            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DB.connection_string))
            {
                using (MySqlCommand cmd = new MySqlCommand("GetTrackerTakedown", con))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    using (MySqlDataAdapter sda = new MySqlDataAdapter())
                    {
                        sda.SelectCommand = cmd;
                        sda.Fill(dt);

                    }
                }
            }
            
            return Json(new
            {
                data = dt

            });
        }
        [HttpPost]
        public async Task<JsonResult> InsertHangJob([FromBody]HangJob hj)
        {
            // to be implemented to store data in tables
            return Json(new
            {
                data = "not implemented"

            });
        }
        [HttpPut]
        public async Task<JsonResult> UpdateHangJob()
        {

            // to be implemented to store data in tables

            return Json(new
            {
                data = "Not Implemented"

            });
        }
        [HttpDelete]
        public async Task<JsonResult> DeleteHangJob(HangJob hj)
        {

            // to be implemented to delete record from table


            return Json(new
            {
                data = "Not Implemented"

            }) ;
        }

        [HttpGet]
        public async Task<JsonResult> GetPaintTrackerData()
        {
            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(DB.connection_string))
            {
                string query = null;
                  //open connection to database
                    con.Open();
                query += "SELECT pt.auto_id, pt.emp_no_hang, pt.job_order_no, pt.nmr_no, pt.sequence_no, pt.part_no, pt.paint_color, pt.qty_hung,pt.emp_no_transaction,pt.transaction_type_id,pt.qty_complete,pt.qty_moved,pt.dt_transaction, pt.rework ,";
                query += "DATE_FORMAT(pt.dt_hang, '%m-%d-%Y %H:%i:%s') AS 'dt_hang',DATE_FORMAT(DATE(dt_hang + INTERVAL (7 - DAYOFWEEK(DATE(dt_hang))) DAY), '%m-%d-%Y') AS 'week_ending', ";
                query += "pt.emp_no_takedown, pt.qty_good, pt.qty_rejected, m.reject_text, pt.rejection_notes, m.paint_non_paint, m.work_station, ";
                query += "DATE_FORMAT(pt.dt_takedown, '%m-%d-%Y %H:%i:%s') AS 'dt_takedown',mt.transaction_type,e1.last_name as name_hang,e2.last_name as name_takedown, mi.value_stream FROM paint_tracker pt ";
                query += "LEFT JOIN master_reject_code m ON(pt.rejection_code = m.reject_code) ";
                query += " LEFT JOIN master_transaction_type mt ON(pt.transaction_type_id = mt.transaction_id)";
                query += "LEFT JOIN sandc_mildew.master_value_stream mi ON(pt.value_stream_id = mi.value_stream_id)";
                query += "LEFT JOIN employees_hidden e1 ON (pt.emp_no_hang = e1.employee_no) ";
                query += "LEFT JOIN employees_hidden e2 ON (pt.emp_no_takedown = e2.employee_no) limit 0,10";
                MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                    DataSet ds = new DataSet();
                    ds.Clear();
                    da.Fill(dt);
                
            }

            return Json(new
            {
                data = dt

            });
        }
    
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
