﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataService.Models.DatabaseModels
{
    public class DateRange
    {
        public string start_date { get; set; }

        public string end_date { get; set; }

    }
}
