﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using DataService.Models.DatabaseModels;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DataService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomReportsController : Controller
    {
        // GET: api/<CustomReportsController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<CustomReportsController>/5
        [HttpGet("")]
        public async Task<JsonResult>  GetKurtsReport(DateRange dr)
        {
            using (MySqlConnection conn = new MySqlConnection(DB.connection_string))
            {
                string query = "";
                query += "SELECT pt.value_stream_id, pt.paint_color, pt.dt_hang, ";
                query += "pt.qty_good, pt.qty_rejected, pt.rejection_code, pt.dt_takedown ";
                query += "FROM paint_tracker pt  ";
                query += "WHERE(pt.dt_takedown IS NOT NULL AND DATE(dt_takedown) >= '" + dr.start_date + "' AND DATE(dt_takedown) <= '" + dr.end_date + "') ";


                MySqlDataAdapter da = new MySqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                ds.Clear();
                da.Fill(ds, "results");
                return Json(new
                {
                    data = ds

                });
            }
        }
        [HttpGet("")]
        public async Task<JsonResult> GetKurtsSummaryReport(DateRange dr)
        {
            using (MySqlConnection conn = new MySqlConnection(DB.connection_string))
            {
                // open connection to database
                conn.Open();

                string query = "";
                query += "SELECT DATE(dt_hang) AS dt_hang, SUM(qty_hung) AS qty_hung, SUM(qty_rejected) AS qty_rejected ";
                query += "FROM paint_tracker ";
                query += "WHERE(DATE(dt_hang) >= '" + dr.start_date + "' AND DATE(dt_hang) <= '" + dr.end_date + "') ";
                query += "GROUP BY DATE(dt_hang) ";
                query += "ORDER BY DATE(dt_hang); ";

                MySqlDataAdapter da = new MySqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                ds.Clear();
                da.Fill(ds, "results");
                return Json(new
                {
                    data = ds

                });
            }
        }
        [HttpGet("")]
        public async Task<JsonResult> GetKurtsSummaryPmgReport(DateRange dr)
        {
            using (MySqlConnection conn = new MySqlConnection(DB.connection_string))

            {
                // open connection to database
                conn.Open();
                string query = "";
                query += "SELECT DATE(dt_hang) AS dt_hang, SUM(qty_hung) AS qty_hung, SUM(qty_rejected) AS qty_rejected ";
                query += "FROM paint_tracker ";
                query += "WHERE(DATE(dt_hang) >= '" + dr.start_date+ "' AND DATE(dt_hang) <= '" + dr.end_date + "') AND value_stream_id = 37 ";
                query += "GROUP BY DATE(dt_hang) ";
                query += "ORDER BY DATE(dt_hang); ";

                MySqlDataAdapter da = new MySqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                ds.Clear();
                da.Fill(ds, "results");
                return Json(new
                {
                    data = ds

                });

            }
        }

        [HttpGet("")]
        public async Task<JsonResult> GetKurtsRejectReport(DateRange dateRange)
        {
            using (MySqlConnection conn = new MySqlConnection(DB.connection_string))

            {
                // open connection to database
                conn.Open();
                string query = "";
                query += "SELECT DATE(dt_hang) AS dt_hang, SUM(qty_hung) AS qty_hung, SUM(qty_rejected) AS qty_rejected ";
                query += "FROM paint_tracker ";
                query += "WHERE(DATE(dt_hang) >= '" + dateRange.start_date + "' AND DATE(dt_hang) <= '" + dateRange.end_date + "') AND value_stream_id = 37 ";
                query += "GROUP BY DATE(dt_hang) ";
                query += "ORDER BY DATE(dt_hang); ";

                MySqlDataAdapter da = new MySqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                ds.Clear();
                da.Fill(ds, "results");
                return Json(new
                {
                    data = ds

                });

            }
        }
        // POST api/<CustomReportsController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<CustomReportsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<CustomReportsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
